"""Single-scene embedding audit for an ALREADY LOADED model and actual pixels.

No model loading, environment edits, precision-flag changes, or writes by default.
Run in the existing Python session; see REPORT.html or READ_ME.txt.
"""
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path

SCENE = "0002267a294e52a7"
PIXELS_SHA = "f0d5c4a3814c428ac6cca1a0ec5293c5d624fe2d5669c926cc9d3c594e7ab4ac"
PARAMETER_SHA = {
    "class_embedding": "2ffe312fbc671217cf3cd0f98faee072604336ffe387466c5074015cbddd690e",
    "position_embedding": "49f52f43097694aece525b5d9cac260260fdc7415fcaf6f3ef04c1834a329498",
    "patch_embedding.weight": "425967ed2a49b8bd8b855b2e409bc62610668319252b6c19456872cf096cf1b9",
    "patch_embedding.bias": "22c02c387fde92e85b5ce2fcad6790c68f5dbde2d46d2cda96a02870a48f0069",
}


def tensor_sha(tensor):
    import torch
    return hashlib.sha256(tensor.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()


def tensor_info(tensor):
    return {"shape": list(tensor.shape), "dtype": str(tensor.dtype),
            "stride": list(tensor.stride()), "device": str(tensor.device), "sha256": tensor_sha(tensor)}


def _array_comparison(a, b, raw_a, raw_b):
    import numpy as np
    if a.shape != b.shape or raw_a.shape != raw_b.shape:
        return {"comparable": False, "reason": "shape or element-byte-width mismatch"}
    av, bv = a.reshape(-1).astype(np.float64), b.reshape(-1).astype(np.float64)
    indices = np.flatnonzero(np.any(raw_a != raw_b, axis=1))
    delta = av - bv
    denominator = float(np.linalg.norm(bv))
    numerator = float(np.linalg.norm(delta))
    def safe(value):
        return float(value) if np.isfinite(value) else None
    return {"comparable": True, "raw_bytes_equal": not len(indices),
            "numeric_equal": bool(np.array_equal(av, bv)), "elements": int(av.size),
            "different_elements": int(len(indices)), "max_abs_error": safe(np.max(np.abs(delta))),
            "relative_l2": safe(numerator / denominator) if denominator else (0.0 if numerator == 0 else None),
            "relative_l2_denominator": "L2(second_tensor)",
            "first16": [{"flat_index": int(i), "first": safe(av[i]), "second": safe(bv[i]),
                         "difference": safe(delta[i])} for i in indices[:16]]}


def compare_tensors(first, second):
    import torch
    if first.shape != second.shape or first.dtype != second.dtype:
        return {"comparable": False, "reason": "shape/dtype mismatch"}
    a, b = first.detach().cpu().contiguous(), second.detach().cpu().contiguous()
    result = _array_comparison(a.float().numpy(), b.float().numpy(),
        a.view(torch.uint8).numpy().reshape(-1, a.element_size()),
        b.view(torch.uint8).numpy().reshape(-1, b.element_size()))
    result["torch_equal"] = bool(torch.equal(a, b))
    return result


def precision_state(torch):
    return {"tf32_matmul": torch.backends.cuda.matmul.allow_tf32,
            "tf32_cudnn": torch.backends.cudnn.allow_tf32,
            "bf16_reduced": getattr(torch.backends.cuda.matmul, "allow_bf16_reduced_precision_reduction", None),
            "fp16_reduced": getattr(torch.backends.cuda.matmul, "allow_fp16_reduced_precision_reduction", None),
            "matmul_precision": torch.get_float32_matmul_precision(),
            "autocast": torch.is_autocast_enabled(),
            "cudnn_benchmark": torch.backends.cudnn.benchmark,
            "cudnn_deterministic": torch.backends.cudnn.deterministic,
            "deterministic_algorithms": torch.are_deterministic_algorithms_enabled()}


def audit_embedding(model, pixels, *, keep_tensors=False, reference_file=None):
    """Print JSON; return report or (report, tensors). All operators use no_grad.

    The hash gate runs before any model computation. Diagnostic failure is recorded
    per operator; other native results continue. No mutation of attention or norm.
    """
    import torch
    import torch.nn.functional as F
    environment_before = dict(os.environ)
    flags_before = precision_state(torch)
    report = {"schema": 1, "scene": SCENE, "status": "STARTED", "errors": {},
              "environment": {"torch": str(torch.__version__), "torch_git": torch.version.git_version,
                              "python": __import__("sys").version.split()[0],
                              "torch_cuda_build": torch.version.cuda,
                              "flags": flags_before, "device": str(pixels.device)},
              "pixels": tensor_info(pixels), "parameters": {}, "native": {}, "diagnostics": {}}
    if (list(pixels.shape) != [9, 3, 448, 448] or pixels.dtype != torch.bfloat16
            or report["pixels"]["sha256"] != PIXELS_SHA):
        report["status"] = "STOP_INPUT_MISMATCH"
        print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), flush=True)
        return (report, {}) if keep_tensors else report
    emb = model.vision_model.embeddings
    conv = emb.patch_embedding
    for package in ("transformers", "timm", "torchvision", "numpy", "Pillow"):
        try:
            report["environment"][package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            report["environment"][package] = None
    if pixels.device.type == "cuda":
        report["environment"]["device_name"] = torch.cuda.get_device_name(pixels.device)
    parameters = {"class_embedding": emb.class_embedding, "position_embedding": emb.position_embedding,
                  "patch_embedding.weight": conv.weight, "patch_embedding.bias": conv.bias}
    versions_before = {name: value._version for name, value in parameters.items()}
    for name, value in parameters.items():
        report["parameters"][name] = tensor_info(value)
        report["parameters"][name]["matches_reference_sha"] = tensor_sha(value) == PARAMETER_SHA[name]
    report["parameters_comparable"] = all(v["matches_reference_sha"] for v in report["parameters"].values())
    report["convolution_attributes"] = {"stride": list(conv.stride), "padding": list(conv.padding),
        "dilation": list(conv.dilation), "groups": conv.groups, "kernel_size": list(conv.kernel_size)}
    try:
        source = Path(inspect.getsourcefile(type(emb)))
        report["embedding_source"] = {"path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest()}
    except Exception as error:
        report["errors"]["embedding_source"] = {"type": type(error).__name__, "message": str(error)[:1500]}
    report["model_sources"] = {}
    for name, getter in (("chat", lambda: model),
                         ("language_attention", lambda: model.language_model.model.layers[0].self_attn)):
        try:
            obj = getter()
            source = Path(inspect.getsourcefile(type(obj)))
            report["model_sources"][name] = {"class": type(obj).__name__, "path": str(source),
                "sha256": hashlib.sha256(source.read_bytes()).hexdigest()}
        except Exception as error:
            report["errors"][name + "_source"] = {"type": type(error).__name__, "message": str(error)[:1500]}
    tensors = {"pixels": pixels, **{"param_" + k.replace(".", "_"): v for k, v in parameters.items()}}
    def capture(name, operation, section="diagnostics"):
        try:
            tensor = operation()
            tensors[name] = tensor
            report[section][name] = tensor_info(tensor)
            return tensor
        except Exception as error:
            report["errors"][name] = {"type": type(error).__name__, "message": str(error)[:2000]}
            return None
    def compare(name, a, b):
        if a is None or b is None:
            report["diagnostics"][name] = {"skipped": "one input unavailable"}
            return
        try:
            report["diagnostics"][name] = compare_tensors(a, b)
        except Exception as error:
            report["errors"][name] = {"type": type(error).__name__, "message": str(error)[:2000]}
    with torch.no_grad():
        patch = capture("patch", lambda: conv(pixels), "native")
        position = capture("position", lambda: emb._get_pos_embed(emb.position_embedding[:, 1:, :], 32, 32), "native")
        full = capture("full", lambda: emb(pixels), "native")
        if full is not None:
            capture("CLS_output", lambda: full[:, 0, :], "native")
            capture("PATCH_output", lambda: full[:, 1:, :], "native")
        compare("position_vs_uninterpolated", position, emb.position_embedding[:, 1:, :])
        kwargs = dict(stride=conv.stride, padding=conv.padding, dilation=conv.dilation, groups=conv.groups)
        c = capture("native_no_bias", lambda: F.conv2d(pixels, conv.weight, None, **kwargs))
        cb = capture("native_split_bias", lambda: c + conv.bias[None, :, None, None]) if c is not None else None
        compare("native_patch_vs_native_split_bias", patch, cb)
        if flags_before["autocast"]:
            report["errors"]["FP32_references"] = {"type": "AutocastEnabled",
                "message": "FP32 comparisons skipped: do not change existing autocast state during this audit."}
        else:
            a = capture("A", lambda: F.conv2d(pixels.float(), conv.weight.float(), conv.bias.float(), **kwargs).to(pixels.dtype))
            d = capture("fp32_no_bias", lambda: F.conv2d(pixels.float(), conv.weight.float(), None, **kwargs))
            dq = capture("fp32_no_bias_bf16", lambda: d.to(pixels.dtype)) if d is not None else None
            b = capture("B", lambda: dq + conv.bias[None, :, None, None]) if dq is not None else None
            if d is not None:
                separate = capture("fp32_separate_bias_then_cast", lambda: (d + conv.bias.float()[None, :, None, None]).to(pixels.dtype))
                compare("A_vs_fp32_separate_bias_then_cast", a, separate)
            compare("native_patch_vs_A", patch, a)
            compare("native_patch_vs_B", patch, b)
            compare("native_no_bias_vs_fp32_no_bias_bf16", c, dq)
        if patch is not None and position is not None:
            x = capture("X", lambda: torch.cat([emb.class_embedding.expand(pixels.shape[0], 1, -1).to(patch.dtype),
                                               patch.flatten(2).transpose(1, 2)], dim=1))
            p = capture("P", lambda: torch.cat([emb.position_embedding[:, :1, :], position], dim=1).to(patch.dtype))
            if x is not None and p is not None:
                summed = capture("X_plus_P", lambda: x + p)
                summed32 = capture("FP32_add_then_BF16", lambda: (x.float() + p.float()).to(x.dtype))
                compare("full_vs_X_plus_P", full, summed)
                compare("BF16_add_vs_FP32_add_cast", summed, summed32)
    report["preservation"] = {"precision_flags_unchanged": flags_before == precision_state(torch),
        "parameter_versions_unchanged": versions_before == {k: v._version for k, v in parameters.items()},
        "parameter_hashes_unchanged": all(tensor_sha(v) == report["parameters"][k]["sha256"] for k, v in parameters.items()),
        "changed_environment_keys": sorted(k for k in set(environment_before) | set(os.environ)
                                           if environment_before.get(k) != os.environ.get(k))}
    reference_file = Path(reference_file) if reference_file else Path(__file__).with_name("local_results.json")
    if reference_file.is_file():
        reference = json.loads(reference_file.read_text())
        ppu = reference["local_diagnostic"]["data"]
        ppu_tensors = {**ppu["parameters"], **ppu["native"]}
        ppu_tensors.update({k: ppu["diagnostics"][k] for k in ("A", "B", "X", "P", "X_plus_P", "FP32_add_then_BF16")})
        report["against_recorded_PPU"] = {k: tensor_sha(v) == ppu_tensors[k]["sha256"]
            for k, v in tensors.items() if k in ppu_tensors}
        report["against_user_A800"] = {k: tensor_sha(v) == expected
            for k, expected in reference["a800_reference"]["sha256"].items() if k in tensors}
    report["status"] = "COLLECTED_WITH_ERRORS" if report["errors"] else "COLLECTED"
    print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), flush=True)
    return (report, tensors) if keep_tensors else report


def export_tensors(report, tensors, destination):
    """EXPLICIT OPT-IN WRITE: save actual tensor bytes for offline comparison.

    No pickle. Refuses to overwrite. The original audit has no saved PPU tensor
    payload; export on each platform only if additional collection is authorized.
    """
    import numpy as np
    import torch
    destination = Path(destination)
    keys = ["pixels", "patch", "native_no_bias", "fp32_no_bias", "fp32_no_bias_bf16", "A", "B", "position", "full"]
    keys += [name for name in tensors if name.startswith("param_")]
    arrays = {}
    metadata = {"schema": 1, "scene": SCENE, "environment": report["environment"], "tensors": {}}
    for key in keys:
        if key not in tensors:
            continue
        tensor = tensors[key]
        arrays[key] = tensor.detach().cpu().contiguous().view(torch.uint8).numpy().copy()
        metadata["tensors"][key] = tensor_info(tensor)
    arrays["__metadata_utf8__"] = np.frombuffer(json.dumps(metadata, ensure_ascii=False).encode(), dtype=np.uint8)
    with destination.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    return {"path": str(destination), "bytes": destination.stat().st_size,
            "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}


def compare_payloads(first_path, second_path):
    """CPU-only: compare real exported tensors; never infer errors from hashes."""
    import numpy as np
    def decode(raw, meta):
        raw = np.ascontiguousarray(raw, dtype=np.uint8).reshape(-1)
        if hashlib.sha256(raw.tobytes()).hexdigest() != meta["sha256"]:
            raise ValueError("payload integrity mismatch")
        if meta["dtype"] == "torch.bfloat16":
            numeric = (raw.view(np.uint16).astype(np.uint32) << 16).view(np.float32)
            width = 2
        else:
            dtype = {"torch.float32": np.float32, "torch.float64": np.float64}[meta["dtype"]]
            numeric = raw.view(dtype)
            width = np.dtype(dtype).itemsize
        return numeric.reshape(meta["shape"]), raw.reshape(-1, width)
    with np.load(first_path, allow_pickle=False) as a, np.load(second_path, allow_pickle=False) as b:
        ma = json.loads(a["__metadata_utf8__"].tobytes())
        mb = json.loads(b["__metadata_utf8__"].tobytes())
        result = {"first": str(first_path), "second": str(second_path), "environments": [ma["environment"], mb["environment"]], "comparisons": {}}
        for key in sorted(set(ma["tensors"]) & set(mb["tensors"])):
            ia, ib = ma["tensors"][key], mb["tensors"][key]
            if ia["shape"] != ib["shape"] or ia["dtype"] != ib["dtype"]:
                result["comparisons"][key] = {"comparable": False, "reason": "shape/dtype mismatch"}
                continue
            av, ar = decode(a[key], ia)
            bv, br = decode(b[key], ib)
            result["comparisons"][key] = _array_comparison(av, bv, ar, br)
        result["missing_on_first"] = sorted(set(mb["tensors"]) - set(ma["tensors"]))
        result["missing_on_second"] = sorted(set(ma["tensors"]) - set(mb["tensors"]))
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return result


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compare", nargs=2, metavar=("PPU_NPZ", "A800_NPZ"))
    args = parser.parse_args()
    if args.compare:
        compare_payloads(*args.compare)
    else:
        parser.exit(message="Import audit_embedding(model, pixels) in the session that already holds the model and actual input.\n")
