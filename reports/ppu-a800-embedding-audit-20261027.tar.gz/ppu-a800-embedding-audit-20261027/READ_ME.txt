PPU / A800 首层视觉 embedding 单场景诊断交接

先打开 REPORT.html。它是完整离线中文文档，已内嵌所有测量 JSON 和采集脚本。

REPORT.html           详细证据、结论、边界、A800 操作步骤和判定表
local_results.json    从实际执行标准输出提取的完整数值，非重新生成的参考
audit_embedding.py    在已加载 model/pixels 的 Python 会话中运行；默认只打印，不写文件
MANIFEST.json         交付文件 SHA256 和大小

固定场景：0002267a294e52a7
固定提交：6bb7119583513094a169b4c2f2dc2a05ac293aa3

本机 full 已命中原 PPU ba0df597...789d74；首个跨平台差异位于 patch 卷积。
631 个不同元素是本机 native patch 与本机 FP32 参考 B 的比较，不是 PPU–A800 误差。
本包没有实际 PPU/A800 张量载荷，不能从 JSON/SHA 还原全量逐元素误差。

A800 在原模型与输入已加载的会话中执行：
    import runpy
    ns = runpy.run_path('/your/path/audit_embedding.py')
    report, tensors = ns['audit_embedding'](
        model, pixels, keep_tensors=True,
        reference_file='/your/path/local_results.json')

脚本先验证 pixels SHA；错误场景立即停止。
不修改 attention、norm、模型参数、环境变量或全局精度标志，不重新选教师。
参考算子失败会逐项记录并继续其余原生结果。

如另行允许保存真正张量，可显式调用 export_tensors；详见 REPORT.html。
两份真实载荷具备后可在 CPU 比较：
    python3 -B audit_embedding.py --compare ppu_payload.npz a800_payload.npz

本交接包不自动运行 GPU、下载模型、发送消息、修改云端作业或上传文件。
