单场景真实原始输入与模型输入，非示例/随机数据。

raw_front.jpg：源 JPG 原字节。raw_frames.json：原日志帧 100–103 的完整四帧字典。
NumPy 数组以 dtype/shape/hex_bytes 无损保存；load_inputs.restore_raw_frames() 可恢复。
tensors.npz 仅包含 uint8 原始数组和 UTF-8 JSON 元数据，不含 pickle。
BF16 必须按原字节重解释；不要将这些 uint8 数值直接 float()/to(BF16)。
model_inputs 中包含五个 tensor 和 use_cache/output_hidden_states/return_dict 三个选项。
auxiliary 包含历史轨迹、导航 one-hot、车辆状态；另附三个角色 mask 和 RGB。

python3 -B ../load_inputs.py --input-dir .
详见 ../REPORT.html 第 18 节；每项 shape、dtype、stride、SHA 均在 metadata.json。
输入是在 CPU 从原文件按冻结源码重建，并经 12 项全量原 PPU 指纹验证。
这不是保留旧进程内存的主张；完整特征生成所需的实际模型输入已逐位恢复。
