"""Verify/load the single-scene raw inputs on CPU; never load or run a model.

    python3 -B load_inputs.py
    model_inputs, auxiliary, tensors, metadata = load_inputs()
    comparison = compare_inputs(existing_actual_model_inputs)

BF16 payloads are restored by reinterpreting uint8 bytes, without a float cast.
"""
import hashlib
import json
from pathlib import Path
import sys

EXPECTED_SHA = {
    'pixels_FP32': 'dd60c99b68580be8e5240951069e390b683a5c28bb8e05125a0bd649c73cd55d',
    'pixel_values': 'f0d5c4a3814c428ac6cca1a0ec5293c5d624fe2d5669c926cc9d3c594e7ab4ac',
    'input_ids': 'f47363f01c681976fa54b1911f3db310a3f474a942b8bcae86df74974105de37',
    'attention_mask': '327128d0b57d5d5888ab4f01d5f9c759b37539a94f0029106ab5e30306446d7e',
    'position_ids': '6a66ecc3aee4ddf1751c21598346235104f5d19a961df6abb94feb272e0ef307',
    'image_flags': 'df070c0849900928e1e85833cce32020c89d2303a9e960510c3c3b79746448b7',
    'history_trajectory': 'b1819fc792ee0380343de7a91d61c7442728bf4373e82e8c9355c9df530a723f',
    'high_command_one_hot': '6855960ee428276148fc8745625c44bde7ae835a9e2fa181cc917af9bcad0d6a',
    'status_feature': '5dc1484333407fc1f3d843d003c150e8188a98ee9b636cbaa06d065c0a8e8cd9',
    'role_image': '621c053c24b6db399240153747c0cb18cfe1c40daf1f6a7c344214f1ef1ed5e6',
    'role_validtext': '9301bb7936486d9b956679b1902cbdd095f94abce86e44dee01f605d9b886db9',
    'role_padding': 'bbdfe78369f0d4464d26c1936f2e1bf8958a8856a444d0177afd20e043af3e28',
}
MODEL_KEYS = ('pixel_values', 'input_ids', 'attention_mask', 'position_ids', 'image_flags')
AUX_KEYS = ('history_trajectory', 'high_command_one_hot', 'status_feature')


def input_directory(directory=None):
    return Path(directory) if directory else Path(__file__).resolve().parent/'inputs'


def load_inputs(directory=None, *, device=None):
    """CPU by default. A device argument transfers actual VLM inputs, except image_flags.

    Preserve the frozen prepare() CPU image_flags convention. Auxiliary tensors and
    the full tensor dictionary stay on CPU. No RNG, precision or module changes.
    """
    import numpy as np
    import torch
    root = input_directory(directory)
    metadata = json.loads((root/'metadata.json').read_text())
    if metadata['scene'] != '0002267a294e52a7' or sys.byteorder != metadata['byte_order']:
        raise ValueError('Unexpected scene or host byte order')
    tensors = {}
    with np.load(root/'tensors.npz', allow_pickle=False) as archive:
        stored = json.loads(archive['__metadata_utf8__'].tobytes())
        if stored != metadata:
            raise ValueError('External and embedded input metadata disagree')
        for key, info in metadata['tensors'].items():
            raw = np.ascontiguousarray(archive[key])
            if raw.dtype != np.uint8:
                raise ValueError(f'{key}: payload is not uint8')
            digest = hashlib.sha256(raw.tobytes()).hexdigest()
            if digest != info['sha256'] or raw.nbytes != info['bytes']:
                raise ValueError(f'{key}: corrupted payload')
            if key in EXPECTED_SHA and digest != EXPECTED_SHA[key]:
                raise ValueError(f'{key}: original PPU fingerprint mismatch')
            dtype = {'torch.bfloat16': torch.bfloat16, 'torch.float32': torch.float32,
                     'torch.int64': torch.int64, 'torch.bool': torch.bool,
                     'torch.uint8': torch.uint8}[info['dtype']]
            value = torch.from_numpy(raw.copy().reshape(-1)).view(dtype).reshape(info['shape'])
            if list(value.stride()) != info['stride']:
                raise ValueError(f'{key}: reconstructed stride mismatch')
            tensors[key] = value
    if not set(EXPECTED_SHA).issubset(tensors):
        raise ValueError('Incomplete original PPU model/auxiliary inputs')
    raw_image_sha = hashlib.sha256((root/'raw_front.jpg').read_bytes()).hexdigest()
    if raw_image_sha != 'a5afee9b743aa413b3f4ccc735424f54be26325fdddde4a6eeb3fcd157eafe0b':
        raise ValueError('Original JPG SHA mismatch')
    model_inputs = {key: tensors[key] for key in MODEL_KEYS}
    if device is not None:
        model_inputs = {key: value if key == 'image_flags' else value.to(device)
                        for key, value in model_inputs.items()}
    model_inputs.update(metadata['forward_options'])
    auxiliary = {key: tensors[key] for key in AUX_KEYS}
    return model_inputs, auxiliary, tensors, metadata


def restore_raw_frames(directory=None):
    """Restore the four original history frames from typed JSON, without pickle."""
    import numpy as np
    def decode(value):
        if isinstance(value, list):
            return [decode(item) for item in value]
        if isinstance(value, dict):
            if value.get('__ndarray__') is True:
                dtype = np.dtype(value['dtype'])
                if dtype.hasobject:
                    raise ValueError('object arrays are not permitted')
                return np.frombuffer(bytes.fromhex(value['hex_bytes']), dtype=dtype).reshape(value['shape']).copy()
            if set(value) == {'__tuple__'}:
                return tuple(decode(item) for item in value['__tuple__'])
            if set(value) == {'__bytes__'}:
                return bytes.fromhex(value['__bytes__'])
            return {key: decode(item) for key, item in value.items()}
        return value
    record = json.loads((input_directory(directory)/'raw_frames.json').read_text())
    if record['scene'] != '0002267a294e52a7' or record['frame_indices'] != [100, 101, 102, 103]:
        raise ValueError('Unexpected historical scene frames')
    return decode(record['frames'])


def compare_inputs(actual, directory=None):
    """Read-only comparison with actual A800 tensors; print first 16 byte differences."""
    import torch
    from audit_embedding import _array_comparison
    _, _, tensors, metadata = load_inputs(directory)
    result = {'scene': metadata['scene'], 'orientation': 'first=actual; second=original PPU input payload',
              'comparisons': {}, 'forward_option_comparisons': {}}
    for key, value in actual.items():
        if key in metadata['forward_options']:
            result['forward_option_comparisons'][key] = value == metadata['forward_options'][key]
        if key not in tensors or not isinstance(value, torch.Tensor):
            continue
        reference = tensors[key]
        if value.shape != reference.shape or value.dtype != reference.dtype:
            result['comparisons'][key] = {'comparable': False, 'reason': 'shape/dtype mismatch',
               'actual_shape': list(value.shape), 'actual_dtype': str(value.dtype),
               'expected_shape': list(reference.shape), 'expected_dtype': str(reference.dtype)}
            continue
        a, b = value.detach().cpu().contiguous(), reference.contiguous()
        item = _array_comparison(a.double().numpy(), b.double().numpy(),
               a.view(torch.uint8).numpy().reshape(-1, a.element_size()),
               b.view(torch.uint8).numpy().reshape(-1, b.element_size()))
        item.update(actual_stride=list(value.stride()), reference_stride=list(reference.stride()))
        result['comparisons'][key] = item
    result['missing_required_model_inputs'] = [key for key in MODEL_KEYS if key not in actual]
    result['all_model_input_bytes_match'] = not result['missing_required_model_inputs'] and all(
        result['comparisons'].get(key, {}).get('raw_bytes_equal', False) for key in MODEL_KEYS)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return result


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir')
    args = parser.parse_args()
    _, _, tensors, metadata = load_inputs(args.input_dir)
    print(json.dumps({'status': 'PASS', 'scene': metadata['scene'], 'device': 'cpu',
          'all_12_original_PPU_fingerprints_match': True,
          'raw_image_sha256': metadata['source_image']['sha256'],
          'tensors': {key: {'shape': list(value.shape), 'dtype': str(value.dtype),
                     'stride': list(value.stride()), 'sha256': metadata['tensors'][key]['sha256']}
                      for key, value in tensors.items()},
          'model_loaded': False, 'model_forward_executed': False},
          ensure_ascii=False, indent=2))
