"""Print version/build metadata and already-loaded runtime state. No model forward.

No environment-variable dump, installation, subprocess, file write, CUDA device
initialization, precision change, or parameter mutation. Run inside the existing
inference process for useful loaded-library and actual-module observations.
"""
import hashlib
import importlib.metadata
import inspect
import json
from pathlib import Path
import platform
import sys


def collect_environment(model=None):
    import torch
    from audit_embedding import precision_state
    packages = {}
    for distribution in importlib.metadata.distributions():
        name = distribution.metadata['Name']
        if name:
            packages[name] = distribution.version
    state = {'schema': 1, 'python': sys.version, 'executable': sys.executable,
             'platform': platform.platform(), 'packages': dict(sorted(packages.items())),
             'torch': {'version': str(torch.__version__), 'git': torch.version.git_version,
                       'cuda_build': torch.version.cuda, 'hip': torch.version.hip,
                       'config_show': torch.__config__.show()},
             'precision_flags': precision_state(torch), 'errors': {},
             'CUDA_already_initialized': torch.cuda.is_initialized()}
    if torch.cuda.is_initialized():
        state['active_device'] = torch.cuda.current_device()
        state['device_name'] = torch.cuda.get_device_name(state['active_device'])
    release = Path('/usr/local/PPU_SDK/release.yaml')
    if release.is_file():
        state['PPU_SDK_release'] = release.read_text()
    try:
        state['already_loaded_relevant_libraries'] = sorted({
            line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines()
            if '/' in line and any(word in line.lower() for word in
                ('ppu_sdk', 'libtorch', 'libcuda', 'libcudnn', 'libcublas', 'acblas', 'acdnn', 'libc10'))})
    except Exception as exc:
        state['errors']['loaded_libraries'] = f'{type(exc).__name__}: {exc}'
    if model is not None:
        try:
            layers = model.language_model.model.layers
            state['actual_language_attention_classes'] = [type(layer.self_attn).__name__ for layer in layers]
            state['language_model_attn_implementation'] = getattr(model.language_model.model, '_attn_implementation', None)
            state['language_config_attn_implementation'] = getattr(model.language_model.config, '_attn_implementation', None)
            state['actual_vision_use_flash_attn'] = [layer.attn.use_flash_attn for layer in model.vision_model.encoder.layers]
            state['source_files'] = {}
            for name, obj in [('vision', model.vision_model.embeddings), ('chat', model), ('qwen', layers[0].self_attn)]:
                path = Path(inspect.getfile(type(obj)))
                state['source_files'][name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        except Exception as exc:
            state['errors']['actual_model_metadata'] = f'{type(exc).__name__}: {exc}'
    print(json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False))
    return state


if __name__ == '__main__':
    collect_environment()
