"""Load the same frozen VLM by its original entry, then call A800's exact exporter.

The former local diagnostic process has exited. This is explicitly a fresh load
of the frozen original model, not a claim to reuse its former Python object.
No precision/attention/norm override; no full VLM or action-head forward.
"""
from pathlib import Path
import datetime
import hashlib
import inspect
import json
import runpy
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = Path('/mnt/data_and_weight/WM_Group/sjc_workspace/ReCogDrive/1026-interface_teacher_portable/repo')
DEST = Path('/mnt/workspace/project/VLA-AD-ppu-a800-handoff-20261027/reports/ppu-a800-alignment-followup-20261027')
VLM = Path('/mnt/data_and_weight/WM_Group/yehr_workspace/ReCogDrive/ReCogDrive/recogdrive/ReCogDrive-VLM-2B')
sys.path.insert(0, str(REPO/'vendor/upstream'))

import torch
from audit_embedding import tensor_info, precision_state, PARAMETER_SHA, PIXELS_SHA
from load_inputs import load_inputs

frozen = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
assert frozen == '6bb7119583513094a169b4c2f2dc2a05ac293aa3', frozen
inputs, auxiliary, cpu_tensors, input_meta = load_inputs()
assert input_meta['tensors']['pixel_values']['sha256'] == PIXELS_SHA
flags_before_import = precision_state(torch)
print('INPUT_IDENTITY_VERIFIED', PIXELS_SHA, flush=True)

# Same optional wandb exclusion as the prior successful local diagnostic. It is
# scoped to this child process and does not affect model arithmetic/settings.
sys.modules['wandb'] = None
from model.recogdrive_backbone import RecogDriveBackbone
print('LOADING_ORIGINAL_ENTRY', str(VLM), flush=True)
backbone = RecogDriveBackbone('internvl', str(VLM), 'cuda')
model = backbone.model
pixels = inputs['pixel_values'].to(next(model.parameters()).device)
emb = model.vision_model.embeddings
conv = emb.patch_embedding
parameters = {'class_embedding': emb.class_embedding, 'position_embedding': emb.position_embedding,
              'patch_embedding.weight': conv.weight, 'patch_embedding.bias': conv.bias}
parameter_info = {key: tensor_info(value) for key, value in parameters.items()}
for key, info in parameter_info.items():
    assert info['sha256'] == PARAMETER_SHA[key], (key, info)
versions = {key: value._version for key, value in parameters.items()}
flags_loaded = precision_state(torch)
assert flags_loaded == flags_before_import, (flags_before_import, flags_loaded)
print('FOUR_ACTUAL_DEVICE_PARAMETERS_VERIFIED', flush=True)

# Use the exact incoming exporter without editing it.
export_path = DEST/'export_ppu_native_C.py'
export = runpy.run_path(str(export_path))['export_ppu_native_C']
result = export(model, pixels, str(DEST/'ppu_native_no_bias.npz'))
assert precision_state(torch) == flags_loaded
assert versions == {key: value._version for key, value in parameters.items()}
assert all(tensor_info(value)['sha256'] == parameter_info[key]['sha256'] for key, value in parameters.items())
source_info = {}
for key, value in [('vision', emb), ('chat', model)]:
    path = Path(inspect.getfile(type(value)))
    source_info[key] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
receipt = {'schema': 1, 'time_UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'scene': input_meta['scene'], 'frozen_commit': frozen,
           'origin_followup_commit': '32bafef',
           'model_lifetime': 'Previous diagnostic process exited. Fresh load of the identical frozen model through original RecogDriveBackbone entry; not the former in-memory object.',
           'entry': "RecogDriveBackbone('internvl', original_VLM_path, 'cuda')",
           'VLM_path': str(VLM), 'pixels': tensor_info(pixels), 'parameters': parameter_info,
           'precision_before_model_load': flags_before_import, 'precision_before_export': flags_loaded,
           'precision_after_export': precision_state(torch),
           'parameter_versions_and_hashes_unchanged': True,
           'torch': str(torch.__version__), 'torch_git': torch.version.git_version,
           'device': torch.cuda.get_device_name(pixels.device),
           'PPU_SDK_release': Path('/usr/local/PPU_SDK/release.yaml').read_text(),
           'source_files': source_info,
           'exporter_sha256': hashlib.sha256(export_path.read_bytes()).hexdigest(),
           'source_exporter_modified': False,
           'arithmetic': 'Only native BF16 F.conv2d with bias=None in supplied exporter, under no_grad. No full VLM/action forward, FP32 convolution or teacher search.',
           'optional_import_handling': 'sys.modules[wandb]=None in this child only, same as prior successful local diagnostic; no package/environment/precision mutation.',
           'file': result}
(DEST/'PPU_EXPORT_RECEIPT.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
(DEST/'ppu_native_no_bias.npz.sha256').write_text(result['sha256']+'  ppu_native_no_bias.npz\n')
(ROOT/'native_C_export_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
print('EXPORT_COMPLETE', json.dumps(result, ensure_ascii=False), flush=True)
