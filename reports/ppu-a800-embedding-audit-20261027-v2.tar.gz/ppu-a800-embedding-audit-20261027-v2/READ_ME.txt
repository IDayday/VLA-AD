PPU / A800 单场景视觉 embedding 诊断交接 v2

先打开 REPORT.html。第 15–20 节为本版新增内容；第 20 节合并 A800 最新证据。
固定场景：0002267a294e52a7
固定教师提交：6bb7119583513094a169b4c2f2dc2a05ac293aa3

本版新增：
- 原 PPU 与本机 Python 库/构建/SDK 信息；本机完整 390 项版本。
- 原 PPU 完整特征链的单场景中间量指纹，与本机首层结果分开标注。
- inputs/：原 JPG、四帧原始元数据、完整 prompt 和实际输入 NPZ。
  12 项模型输入/辅助状态/角色 mask 全部命中原 PPU SHA。
- load_inputs.py：CPU 读取/校验，并与 A800 实际输入直接逐元素比较。
- source_snapshot/：冻结的预处理、模型/接口、配置、完整 tokenizer 文件；无大权重。
- original_ppu_golden_outputs.npz：既有该单场景 Base/冻结选择6轨迹、评分、shift。
- collect_environment.py：只打印库版本/构建/实际模块及精度状态，不运行模型。
- a800_followup/：A800 32bafef 的后续证据和原版 C 导出脚本。
- native_C_export_receipt.json / native_C_remote_verification.json：真正 C 的导出和远端核验。

实际 C 单独保存在同一分支（避免在压缩包中重复 14.9 MB）：
  reports/ppu-a800-alignment-followup-20261027/ppu_native_no_bias.npz
完整下载 URL 和不可变 commit 见 native_C_remote_verification.json。
C 原始字节 SHA：c04efdfc37e1d5d2fc0ce8bf618df389103f20a7c183e53e708eaf3dbaf2389b
NPZ 文件 SHA：9c1abc99ea9ba94db1160cdd89c566c5c2df4d2efacaed8e83d801deaa3a302d

先只读验证输入：
  python3 -B load_inputs.py
在 A800 已有 Python 会话中：
  from load_inputs import load_inputs, compare_inputs
  compare_inputs(actual_inputs)
  inputs, auxiliary, cpu_tensors, metadata = load_inputs()

默认不自动运行 GPU，不安装/下载模型，不改参数、attention/norm 或精度标志。
若接续首层核查，audit_embedding.py 仍需原模型和实际 pixels；报告字段已按 A800
审阅过的单行修正更新，无数值操作改变，详见 collector_patch_receipt.json。

关键判断：A800 匹配 TF32=True 后，FP32 A/B 两端一致，但原生 BF16 无 bias C
仍不同。真实 PPU C 已提供，下一步可在 A800 做精确比较及后续路径注入。
当前尚未完成完整 VLM/接口对齐；本机没有重新生成教师或运行批量任务。
